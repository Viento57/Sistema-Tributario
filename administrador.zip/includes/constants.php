<?php
define("DB", "tributos3");
define("HOST", "localhost");
define("USER", "first");
define("PASS", "3674783");
  
?>